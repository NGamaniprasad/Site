// routes/userRoutes.js
const express = require("express");
const router = express.Router();
const User = require("../models/User");

// Signup
router.post("/signup", async (req, res) => {
  const { name, email, password } = req.body;
  await User.create({ name, email, password });
  res.redirect("/courses.html");
});

// Login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email, password });
  if (user) res.redirect("/courses.html");
  else res.send("Invalid credentials");
});

module.exports = router;
