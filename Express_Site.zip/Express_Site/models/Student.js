// // models/Student.js
// const mongoose = require("mongoose");

// const studentSchema = new mongoose.Schema({
//   name: String,
//   course: String,
//   email: String,
//   phone: String,
//   attendance: [{
//     date: String,
//     status: String
//   }]
// });

// module.exports = mongoose.model("Student", studentSchema);

const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  name: { type: String, required: true },
  course: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String, required: true },
  attendance: [{
    date: String,
    status: String
  }]
});

module.exports = mongoose.model("Student", studentSchema);
