require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const User = require('./models/User');
const Attendance = require('./models/Attendance');

const app = express();
const PORT = process.env.PORT || 3000;
const MONGO_URI = process.env.MONGO_URI;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB Connection
mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

// Signup
app.post('/api/signup', async (req, res) => {
  const { username, email, password } = req.body;
  try {
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ error: 'User already exists' });
    const user = new User({ name: username, email, password });
    await user.save();
    res.json({ message: 'Signup successful' });
  } catch {
    res.status(500).json({ error: 'Signup failed' });
  }
});

// Login
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email, password });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    res.json({ message: 'Login successful', user: { name: user.name, email: user.email } });
  } catch {
    res.status(500).json({ error: 'Login failed' });
  }
});

// Attendance
app.post('/attendance', async (req, res) => {
  try {
    const attendance = new Attendance(req.body);
    await attendance.save();
    res.json({ message: 'Attendance submitted' });
  } catch {
    res.status(500).json({ error: 'Error saving attendance' });
  }
});

app.get('/attendance', async (req, res) => {
  try {
    const records = await Attendance.find();
    res.json(records);
  } catch {
    res.status(500).json({ error: 'Error fetching attendance' });
  }
});

// app.put('/attendance', async (req, res) => {
//   const { email, date, status, queries } = req.body;
//   try {
//     const result = await Attendance.updateOne({ email, date }, { $set: { status, queries } });
//     res.json({ message: `${result.modifiedCount} record(s) updated.` });
//   } catch {
//     res.status(500).json({ error: 'Error updating attendance' });
//   }
// });

app.put('/attendance', async (req, res) => {
  const { email, date, status, queries } = req.body;

  if (!email || !date) {
    return res.status(400).json({ error: 'Email and date are required to update.' });
  }

  try {
    const result = await Attendance.updateOne(
      { email, date },
      { $set: { status, queries } }
    );

    res.json({ message: `Updated ${result.modifiedCount} record(s)` });
  } catch (err) {
    res.status(500).json({ error: 'Error updating attendance' });
  }
});


// app.delete('/attendance', async (req, res) => {
//   const { email, date } = req.body;
//   try {
//     const result = await Attendance.deleteOne({ email, date });
//     res.json({ message: `${result.deletedCount} record(s) deleted.` });
//   } catch {
//     res.status(500).json({ error: 'Error deleting attendance' });
//   }
// });
app.delete('/attendance', async (req, res) => {
  const { email, date } = req.body;

  if (!email || !date) {
    return res.status(400).json({ error: 'Email and date are required to delete.' });
  }

  try {
    const result = await Attendance.deleteOne({ email, date });
    res.json({ message: `Deleted ${result.deletedCount} record(s)` });
  } catch (err) {
    res.status(500).json({ error: 'Error deleting attendance' });
  }
});

// In-memory student store
let students = [];

app.get('/students', (req, res) => {
  res.json(students);
});

app.post('/students', (req, res) => {
  const student = { ...req.body, _id: Date.now().toString() };
  students.push(student);
  res.json({ message: 'Student added', student });
});

app.put('/students/:id', (req, res) => {
  const index = students.findIndex(s => s._id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Student not found' });
  students[index] = { ...students[index], ...req.body };
  res.json({ message: 'Student updated' });
});

app.delete('/students/:id', (req, res) => {
  const index = students.findIndex(s => s._id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Student not found' });
  students.splice(index, 1);
  res.json({ message: 'Student deleted' });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
