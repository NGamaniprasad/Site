"""
steps do
open in pycharm do python codes
create index.html file paste below code

<!DOCTYPE html>
<html>
<head>
    <title>Chat App</title>
</head>
<body>
    <h2>Real-Time Chat</h2>

    <input type="text" id="token" placeholder="Paste JWT token here" style="width:400px;">
    <button onclick="connectWS()">Connect</button>
    <br><br>

    <textarea id="chat" cols="60" rows="15" readonly></textarea>
    <br>
    <input type="text" id="msg" placeholder="Type message..." style="width:400px;">
    <button onclick="sendMessage()">Send</button>

    <script>
        let ws;

        function connectWS() {
            const token = document.getElementById('token').value;
            if (!token) {
                alert("Paste your token!");
                return;
            }
            ws = new WebSocket(`ws://127.0.0.1:8000/ws/chat?token=${token}`);

            ws.onopen = () => {
                appendChat("✅ Connected to chat server");
            };

            ws.onmessage = (event) => {
                appendChat(event.data);
            };

            ws.onclose = () => {
                appendChat("❌ Disconnected from server");
            };
        }

        function sendMessage() {
            const msg = document.getElementById('msg').value;
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(msg);
                document.getElementById('msg').value = "";
            } else {
                alert("Connect first!");
            }
        }

        function appendChat(text) {
            const chat = document.getElementById('chat');
            chat.value += text + "\n";
            chat.scrollTop = chat.scrollHeight;
        }
    </script>
</body>
</html>


and

http://127.0.0.1:8000/docs


a) Register User

Click POST /register → Try it out

Body:

{
  "username": "ram",
  "password": "123"
}


Click Execute → Response:

{"message":"User registered"}

b) Login User

Click POST /login → Try it out

Body:

{
  "username": "ram",
  "password": "123"
}


Click Execute → Response shows:

{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6..."
}


📌 Copy this token — we’ll use it in WebSocket.


many person can login by genartion many tokens
"""
from fastapi import FastAPI, WebSocket, Depends, HTTPException
from sqlalchemy.orm import Session
from database import SessionLocal, engine
from models import Base, User, Message
from auth import hash_password, verify_password, create_access_token
from jose import jwt

Base.metadata.create_all(bind=engine)

app = FastAPI()
SECRET_KEY = "SECRET123"
ALGORITHM = "HS256"

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ---------------- AUTH ----------------

@app.post("/register")
def register(username: str, password: str, db: Session = Depends(get_db)):
    user = User(username=username, password=hash_password(password))
    db.add(user)
    db.commit()
    return {"message": "User registered"}

@app.post("/login")
def login(username: str, password: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == username).first()
    if not user or not verify_password(password, user.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token({"sub": username})
    return {"access_token": token}

# ---------------- CHAT ----------------

active_connections = []

@app.websocket("/ws/chat")
async def chat(websocket: WebSocket):
    token = websocket.query_params.get("token")
    payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    username = payload.get("sub")

    await websocket.accept()
    active_connections.append(websocket)

    try:
        while True:
            msg = await websocket.receive_text()
            for conn in active_connections:
                await conn.send_text(f"{username}: {msg}")
    except:
        active_connections.remove(websocket)
