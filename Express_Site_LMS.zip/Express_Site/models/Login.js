

const mongoose = require('mongoose');

const LoginSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  password: { type: String, required: true },        // hashed password
  plainPassword: { type: String },                    // plain password
});

module.exports = mongoose.model('Login', LoginSchema);
