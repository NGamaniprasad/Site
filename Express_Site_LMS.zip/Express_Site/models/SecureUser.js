// // // const mongoose = require("mongoose");

// // // const secureUserSchema = new mongoose.Schema({
// // //   name: String,
// // //   email: { type: String, unique: true },
// // //   course: String,
// // //   phone: String,
// // //   plainPassword: String, // visible to admin only
// // //   passwordHash: String
// // // });

// // // module.exports = mongoose.model("SecureUser", secureUserSchema);

// // const mongoose = require("mongoose");

// // const secureUserSchema = new mongoose.Schema({
// //   name: String,
// //   email: { type: String, unique: true },
// //   course: String,
// //   phone: String,
// //   plainPassword: String,
// //   passwordHash: String
// // });

// // module.exports = mongoose.model("SecureUser", secureUserSchema);

// const SecureUserSchema = new mongoose.Schema({
//   email: { type: String, unique: true, required: true },
//   password: { type: String, required: true },
//   createdAt: { type: Date, default: Date.now }
// });

// const SecureUser = mongoose.model('SecureUser', SecureUserSchema);
