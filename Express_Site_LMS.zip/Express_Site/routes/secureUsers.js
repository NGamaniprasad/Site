
// // const express = require("express");
// // const router = express.Router();
// // const bcrypt = require("bcrypt");
// // const SecureUser = require("../models/SecureUser");

// // const ADMIN_PASSWORD = "Gamani@505891LMS";

// // // Helper function
// // function generateRandomPassword() {
// //   const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$!";
// //   let pwd = "";
// //   for (let i = 0; i < 10; i++) {
// //     pwd += chars[Math.floor(Math.random() * chars.length)];
// //   }
// //   return pwd;
// // }

// // // Admin creates student with random password
// // router.post("/register", async (req, res) => {
// //   const { adminPassword, name, email, course, phone } = req.body;

// //   if (adminPassword !== ADMIN_PASSWORD) {
// //     return res.status(401).json({ error: "Unauthorized" });
// //   }

// //   try {
// //     const plainPassword = generateRandomPassword();
// //     const passwordHash = await bcrypt.hash(plainPassword, 10);

// //     const user = new SecureUser({
// //       name,
// //       email,
// //       course,
// //       phone,
// //       plainPassword,     // this will be stored in DB
// //       passwordHash
// //     });

// //     await user.save();
// //     res.json({ message: "Student registered", plainPassword });
// //   } catch (err) {
// //     console.error("Register error:", err);
// //     res.status(400).json({ error: "Registration failed", details: err.message });
// //   }
// // });

// // module.exports = router;

// const express = require("express");
// const router = express.Router();
// const bcrypt = require("bcryptjs");
// const SecureUser = require("../models/SecureUser");

// // Add student
// router.post("/", async (req, res) => {
//   try {
//     const { name, email, course, phone } = req.body;
//     const plainPassword = Math.random().toString(36).slice(-8);
//     const passwordHash = await bcrypt.hash(plainPassword, 10);

//     const student = new SecureUser({ name, email, course, phone, plainPassword, passwordHash });
//     await student.save();

//     res.json({ message: "Student added successfully!", password: plainPassword });
//   } catch (err) {
//     res.status(500).json({ error: err.code === 11000 ? "Email already exists!" : err.message });
//   }
// });

// // Get all students
// router.get("/", async (req, res) => {
//   const students = await SecureUser.find();
//   res.json(students);
// });

// // Update student
// router.put("/:id", async (req, res) => {
//   try {
//     await SecureUser.findByIdAndUpdate(req.params.id, req.body);
//     res.json({ message: "Student updated successfully!" });
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// // Delete student
// router.delete("/:id", async (req, res) => {
//   try {
//     await SecureUser.findByIdAndDelete(req.params.id);
//     res.json({ message: "Student deleted successfully!" });
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// // Student login
// router.post("/login", async (req, res) => {
//   const { email, password } = req.body;
//   const student = await SecureUser.findOne({ email });

//   if (!student) return res.status(401).json({ error: "User not found" });

//   const isMatch = await bcrypt.compare(password, student.passwordHash);
//   if (!isMatch) return res.status(401).json({ error: "Invalid password" });

//   res.json({ message: "Login successful!" });
// });

// module.exports = router;

const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const Login = require('../models/Login');

function generatePassword() {
  return crypto.randomBytes(4).toString('hex'); // 8-character hex password
}

// router.post('/generate-password', async (req, res) => {
//   const { email, name } = req.body;
//   if (!email || !name) return res.status(400).json({ error: 'Email and name required' });

//   try {
//     const existing = await Login.findOne({ email });
//     if (existing) return res.status(400).json({ error: 'Account already exists' });

//     const plainPassword = generatePassword();
//     const hashedPassword = await bcrypt.hash(plainPassword, 10);

//     const newLogin = new Login({ email, name, password: hashedPassword });
//     await newLogin.save();
//     res.json({ message: 'Password generated successfully. Please contact admin to get your password.' });


//     // res.json({ message: 'Password generated', email, password: plainPassword });
//   } catch (err) {
//     res.status(500).json({ error: 'Server error: ' + err.message });
//   }
// });
//const crypto = require('crypto');
//const bcrypt = require('bcrypt');

function generatePassword() {
  return crypto.randomBytes(4).toString('hex'); // 8-char hex pwd
}

router.post('/generate-password', async (req, res) => {
  const { email, name } = req.body;
  if (!email || !name) return res.status(400).json({ error: 'Email and name required' });

  try {
    const existing = await Login.findOne({ email });
    if (existing) return res.status(400).json({ error: 'Account already exists' });

    const plainPassword = generatePassword();
    const hashedPassword = await bcrypt.hash(plainPassword, 10);

    const newLogin = new Login({
      email,
      name,
      password: hashedPassword,
      plainPassword: plainPassword, // store plain pwd here
    });

    await newLogin.save();
    res.json({ message: 'Password generated', email, password: plainPassword }); // send plain pwd back once
  } catch (err) {
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
});


router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Missing credentials' });

  try {
    const user = await Login.findOne({ email });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ error: 'Invalid credentials' });

    res.json({ message: 'Login successful' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// router.get('/admin/logins', async (req, res) => {
//   try {
//     const logins = await Login.find({}, { email: 1, name: 1, password: 1, _id: 0 });
//     res.json(logins);
//   } catch (err) {
//     res.status(500).json({ error: 'Error fetching logins' });
//   }
// });
router.get('/admin/logins', async (req, res) => {
  try {
    const logins = await Login.find({}, { email: 1, name: 1, plainPassword: 1, _id: 0 });
    res.json(logins);
  } catch (err) {
    res.status(500).json({ error: 'Error fetching logins' });
  }
});

router.get('/admin/update-attempts', async (req, res) => {
  try {
    const attempts = await UpdateAttempt.find().sort({ timestamp: -1 });
    res.json(attempts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
