from django.db import models
#task1
class User(models.Model):
    username = models.CharField(max_length=100, unique=True)
    age = models.IntegerField()
    phone_number = models.CharField(max_length=15, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=255)

    def __str__(self):
        return self.username
#Task_2
#
# class Player(models.Model):
#     PLAYER_SPECIALIZATION_CHOICES = [
#         ('Batter', 'Batter'),
#         ('Bowler', 'Bowler'),
#         ('Allrounder', 'Allrounder'),
#     ]
#
#     name = models.CharField(max_length=100)
#     age = models.IntegerField()
#     specialization = models.CharField(
#         max_length=10, choices=PLAYER_SPECIALIZATION_CHOICES)
#     country = models.CharField(max_length=50)
#     base_price = models.DecimalField(max_digits=10, decimal_places=2)
#     sold_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
#     sold_team = models.CharField(max_length=50, null=True, blank=True)
#
#     def __str__(self):
#         return self.name

class Player(models.Model):
    PLAYER_SPECIALIZATION_CHOICES = [
        ('Batter', 'Batter'),
        ('Bowler', 'Bowler'),
        ('Allrounder', 'Allrounder'),
    ]

    name = models.CharField(max_length=100)
    age = models.IntegerField()
    specialization = models.CharField(
        max_length=10, choices=PLAYER_SPECIALIZATION_CHOICES)
    country = models.CharField(max_length=50)

    # Increased from 10 → 12 digits to allow high-value IPL prices
    base_price = models.DecimalField(max_digits=12, decimal_places=2)
    sold_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    sold_team = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return self.name
#Task3

#-------------perfect

#gooodALLSET
from django.db import models

# Define the Team model
class Team(models.Model):
    name = models.CharField(max_length=100)
    played = models.IntegerField(default=0)
    won = models.IntegerField(default=0)
    lost = models.IntegerField(default=0)
    points = models.IntegerField(default=0)

    def __str__(self):
        return self.name

    def update_points(self, is_win):
        """Update points based on match result."""
        self.played += 1
        if is_win:
            self.won += 1
            self.points += 2  # 2 points for a win
        else:
            self.lost += 1
        self.save()

# Define the Match model
class Match(models.Model):
    team1 = models.ForeignKey(Team, related_name='matches_played_as_team1', on_delete=models.CASCADE)
    team2 = models.ForeignKey(Team, related_name='matches_played_as_team2', on_delete=models.CASCADE)
    winner = models.ForeignKey(Team, related_name='matches_won', null=True, blank=True, on_delete=models.SET_NULL)
    date = models.DateField()

    def __str__(self):
        return f"{self.team1.name} vs {self.team2.name} on {self.date}"

    def set_winner(self, winner_team):
        """Set winner and update points."""
        self.winner = winner_team
        self.team1.update_points(winner_team == self.team1)
        self.team2.update_points(winner_team == self.team2)
        self.save()
#--------------------------------4
from django.db import models

# Batsman model
class Batsman(models.Model):
    name = models.CharField(max_length=100)
    team = models.CharField(max_length=100)
    total_runs = models.IntegerField()

    batting_avg = models.FloatField()
    fours = models.IntegerField()
    sixes = models.IntegerField()
    ducks = models.IntegerField()
    outs = models.IntegerField()

    def __str__(self):
        return self.name

# MostWickets model
class MostWickets(models.Model):
    name = models.CharField(max_length=100)
    team = models.CharField(max_length=100)
    wickets = models.IntegerField()
    bowling_avg = models.FloatField()

    def __str__(self):
        return self.name

#----SET
from django.db import models

class Ipl_Teams(models.Model):
    team_name = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.team_name

class AuctionPlayer(models.Model):
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField()
    country = models.CharField(max_length=100)
    base_price = models.DecimalField(max_digits=10, decimal_places=2)
    sold_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    sold_team = models.ForeignKey(Ipl_Teams, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.name
#------------------------------------

#------------------------------------------------

from django.db import models

# Model for Image
class Image(models.Model):
    title1 = models.CharField(max_length=100)
    image = models.ImageField(upload_to='images/')  # Store images in 'media/images/'

    def __str__(self):
        return self.title1

# Model for Video
class Video(models.Model):
    title2= models.CharField(max_length=100)
    video = models.FileField(upload_to='videos/')  # Store videos in 'media/videos/'

    def __str__(self):
        return self.title2

# Model for File
class File(models.Model):
    title3 = models.CharField(max_length=100)
    file = models.FileField(upload_to='files/')  # Store files in 'media/files/'

    def __str__(self):
        return self.title3a

class File1(models.Model):
    file = models.FileField(upload_to='files/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"File uploaded at {self.uploaded_at}"

