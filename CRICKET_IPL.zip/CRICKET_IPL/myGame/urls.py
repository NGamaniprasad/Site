from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('myRole.urls')),
]

urlpatterns = urlpatterns+static(settings.MEDIA_URL,
document_root=settings.MEDIA_ROOT)


# def contact_view(request):
#     if request.method == "POST":
#         name = request.POST.get('name')
#         email = request.POST.get('email')
#         message = request.POST.get('message')
#
#         try:
#             # Construct the email content
#             subject = f"Message from {name} via IPL Auction Tracker"
#             full_message = f"Name: {name}\nEmail: {email}\n\nMessage:\n{message}"
#
#             # Send email
#             send_mail(
#                 subject=subject,
#                 message=full_message,
#                 from_email=email,
#                 recipient_list=['your-email@example.com'],  # Replace with your desired email address
#                 fail_silently=False,
#             )
#
#             # If email is sent successfully, show a success message
#             messages.success(request, "Your message has been sent successfully. We'll get back to you soon!")
#
#         except Exception as e:
#             # If there is an error sending the email, show an error message
#             messages.error(request, f"An error occurred while sending your message: {e}")
#
#         return redirect('contact')  # Redirect back to the contact page (or any other success URL)
#
#     return render(request, 'code.html')  # Render the contact form for GET request
